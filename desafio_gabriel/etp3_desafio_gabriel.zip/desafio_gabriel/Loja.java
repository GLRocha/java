public class Loja {

  private String nome;
  private int quantidadeFuncionarios;
  private double salarioBaseFuncionario;
  private Endereco endereco;
  private Data dataFundacao;


  public Loja(String nome, int quantidadeFuncionarios, double salarioBaseFuncionario, Endereco endereco, Data dataFundacao) {
    this.nome = nome;
    this.quantidadeFuncionarios = quantidadeFuncionarios;
    this.salarioBaseFuncionario = salarioBaseFuncionario;
    this.endereco = endereco;
    this.dataFundacao = dataFundacao;
  }

  public Loja(String nome, int quantidadeFuncionarios, Endereco endereco, Data dataFundacao) {
    this.nome = nome;
    this.quantidadeFuncionarios = quantidadeFuncionarios;
    this.salarioBaseFuncionario = -1;
    this.endereco = endereco;
    this.dataFundacao = dataFundacao;
  }
  public Endereco getEndereco() {
    return endereco;
  }

  public void setEndereco(Endereco endereco) {
    this.endereco = endereco;
  }

  public Data getDataFundacao() {
    return dataFundacao;
  }

  public void setDataFundacao(Data dataFundacao) {
    this.dataFundacao = dataFundacao;
  }

  public String getNome() {
    return this.nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public double getSalarioBaseFuncionario() {
    return this.salarioBaseFuncionario;
  }

  public void setSalarioBaseFuncionario(double salarioBaseFuncionario) {
    this.salarioBaseFuncionario = salarioBaseFuncionario;
  }

  public double gastosComSalario() {
    if (salarioBaseFuncionario == -1) {
      return -1;
    }
    return quantidadeFuncionarios * salarioBaseFuncionario;
  }

  public int getQuantidadeFuncionarios() {
    return quantidadeFuncionarios;
  }

  public void setQuantidadeFuncionarios(int quantidadeFuncionarios) {
    this.quantidadeFuncionarios = quantidadeFuncionarios;
  }
  
  public char tamanhoDaLoja() {
    if (quantidadeFuncionarios < 10) {
      return 'P';
    } else if (quantidadeFuncionarios >= 10 && quantidadeFuncionarios <= 30) {
      return 'M';
    } else if (quantidadeFuncionarios > 31) {
      return 'G';
    } else {
      // Caso não se encaixe em nenhuma condição (teoricamente impossível)
      return '?';
    }
  }
  
  @Override
  public String toString() {
    return "Loja:\n" +
        "  Nome: " + nome + "\n" +
        "  Funcionários: " + quantidadeFuncionarios + "\n" +
        "  Salário base: " + salarioBaseFuncionario + "\n" +
        "  Endereço: " + (endereco != null ? endereco.toString() : "N/A") + "\n" +
        "  Data de Fundação: " + (dataFundacao != null ? dataFundacao.toString() : "N/A");
  }


}
